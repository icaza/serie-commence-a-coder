﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Premier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Bouton_Btn_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Je commence à coder " + ZoneText_Txt.Text);

            ZoneText_Txt.Text = "Je commence à coder";

            Bouton_Btn.Text = "Bouton cliqué";
        }
    }
}
